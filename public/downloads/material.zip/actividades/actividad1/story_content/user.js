function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6q8amDP8U3M":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

